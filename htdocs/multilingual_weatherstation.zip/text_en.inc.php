<?
  $title = 'Kenneth\'s Weather Station, Glostrup, Denmark';
	
	$DirUnit = '&deg';
	$Percent = '%';
	$PressureUnit = 'hPa';
	$RainUnit = 'mm';
	$SpeedUnit = 'm/s';
	$TempUnit = '&deg;C';
  $Minimum = 'Minimum';
  $Maximum = 'Maximum';
	
  $Forecast = 'Forecast';
	$ForecastArr = array('Cloudy' => 'Cloudy'
                      ,'Rainy'  => 'Rainy'
                      ,'Sunny'  => 'Sunny'
                      );
	$Tendency = 'Tendency';
	$TendencyArr = array('Falling' => 'Falling'
                      ,'Rising'  => 'Rising'
                      ,'Steady'  => 'Steady'
                      );
	
  $RP = 'Relative Pressure';
	$WS = 'Wind Speed';
  $DIRtext = 'Wind Direction';
	$DirectionArr = array('N'   => 'N'
	                     ,'NNE' => 'N-N-E'
	                     ,'NE'  => 'N-E'
	                     ,'ENE' => 'E-N-E'
	                     ,'E'   => 'E'
	                     ,'ESE' => 'E-S-E'
	                     ,'SE'  => 'S-E'
	                     ,'SSE' => 'S-S-E'
	                     ,'S'   => 'S'
	                     ,'SSW' => 'S-S-W'
	                     ,'SW'  => 'S-W'
	                     ,'WSW' => 'W-S-W'
	                     ,'W'   => 'W'
	                     ,'WNW' => 'W-N-W'
	                     ,'NW'  => 'N-W'
	                     ,'NNW' => 'N-N-W'
	                     );
	$DIRlast5Dirs = 'Last 5 directions';
  $Rtot = 'Rain Total';
	$Rtotsince = 'Since';
	$R24h = 'Rain last 24 hours';
	$R1h = 'Rain last 1 hour';
	$Ti = 'Temperature, Indoor';
	$To = 'Temperature, Outdoor';
  $DP = 'Dewpoint';
	$WC = 'Windchill';
	$RHi = 'Relative Humidity, Indoor';
	$RHo = 'Relative Humidity, Outdoor';
	
  $Footer = 'Weather Data are loaded directly from Weather Station which gives a 5-30 seconds delay.';

  $Link1 = 'Weather Index';  
  $Link2 = 'Weather Graphs';
  $Link3 = 'World Weather'; 
  $Link4 = 'Kenneth\'s Homepage';
?>
