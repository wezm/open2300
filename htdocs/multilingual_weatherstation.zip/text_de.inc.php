<?
  $title = 'Kenneth\'s Wetterstation, Glostrup, D&auml;nemark';

	$DirUnit = '&deg';
	$Percent = '%';
	$PressureUnit = 'hPa';
	$RainUnit = 'mm';
	$SpeedUnit = 'm/s';
	$TempUnit = '&deg;C';
  $Minimum = 'Minimum';
  $Maximum = 'Maximum';

  $Forecast = 'Prognose';
	$ForecastArr = array('Cloudy' => 'Wolkig'
                      ,'Rainy'  => 'Regnerisch'
                      ,'Sunny'  => 'Sonnig'
                      );
	$Tendency = 'Tendenz';
	$TendencyArr = array('Falling' => 'Fallend'
                      ,'Rising'  => 'Steigend'
                      ,'Steady'  => 'Best&auml;ndig'
                      );

  $RP = 'relativer Luftdruck';
	$WS = 'Windgeschwindigkeit';
  $DIRtext = 'Windrichtung';
	$DirectionArr = array('N'   => 'N'
	                     ,'NNE' => 'N-N-O'
	                     ,'NE'  => 'N-O'
	                     ,'ENE' => 'O-N-O'
	                     ,'E'   => 'O'
	                     ,'ESE' => 'O-S-O'
	                     ,'SE'  => 'S-O'
	                     ,'SSE' => 'S-S-O'
	                     ,'S'   => 'S'
	                     ,'SSW' => 'S-S-W'
	                     ,'SW'  => 'S-W'
	                     ,'WSW' => 'W-S-W'
	                     ,'W'   => 'W'
	                     ,'WNW' => 'W-N-W'
	                     ,'NW'  => 'N-W'
	                     ,'NNW' => 'N-N-W'
	                     );
	$DIRlast5Dirs = 'Letzte 5 Richtungen';
  $Rtot = 'Regen gesamt';
	$Rtotsince = 'Seit';
	$R24h = 'Regen der letzten 24 Stunden';
	$R1h = 'Regen der letzten Stunde';
	$Ti = 'Temperatur, innen';
	$To = 'Temperatur, aussen';
  $DP = 'Taupunkt';
	$WC = 'Windk&uuml;hle';
	$RHi = 'Relative Luftfeuchtigkeit, innen';
	$RHo = 'Relative Luftfeuchtigkeit, aussen';
	
  $Footer = 'Die Wetterdaten werden direkt von der Wetterstation geladen, wodurch eine Verz&ouml;gerung von 5-30 Sekunden entstehen kann.';

  $Link1 = 'Wetterindex';  
  $Link2 = 'Wettergrafiken';
  $Link3 = 'Weltwetter'; 
  $Link4 = 'Kenneth\'s Startseite';
?>
